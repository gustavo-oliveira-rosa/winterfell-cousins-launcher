	float bsize = 0;
	if (BORDER_RATIO > aspectRatio)
	{
	if (texcoord.y > 0.5-0.5*aspectRatio/BORDER_RATIO && texcoord.y < 0.5+0.5*aspectRatio/BORDER_RATIO) color *= 1;
	else color *= (1-BORDER_OPACITY);
	}
	if (BORDER_RATIO < aspectRatio)
	{
	if (texcoord.x > 0.5-0.5*BORDER_RATIO/aspectRatio && texcoord.x < 0.5+0.5*BORDER_RATIO/aspectRatio) color *= 1;
	else color *= (1-BORDER_OPACITY);
	}