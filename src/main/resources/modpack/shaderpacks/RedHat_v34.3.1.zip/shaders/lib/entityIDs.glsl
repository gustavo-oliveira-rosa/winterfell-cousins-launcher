
// This is a file that contains the IDs of some blocks, used to do a specific code for a specific block.
// These IDs are used by the terrain and shadow program
// Do not touch if you don't know what you're doing

#define ENTITY_LEAVES        10004
#define ENTITY_VINES         10013
#define ENTITY_TALLGRASS     10005
#define ENTITY_FLOWERS       10007
#define ENTITY_LILYPAD       10014
#define ENTITY_FIRE          10011
#define ENTITY_LAVAFLOWING   10003
#define ENTITY_LAVASTILL     10003
#define ENTITY_OTHER         10016      
#define ENTITY_SEA_LANTERN   169.0
#define ENTITY_NETHER_WART   10012
#define ENTITY_SAPLINGS      10001
#define ENTITY_DEADBUSH      10006
#define ENTITY_CROPS         10009
#define ENTITY_MUSHROOM      10008
#define ENTITY_METALLIC      10015
#define ENTITY_UNDERWATER    10000
#define ENTITY_DOUBLE_GRASS  10017
#define ENTITY_DOUBLE_FLOWER 10018