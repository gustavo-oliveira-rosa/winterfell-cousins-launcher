		
			lenscolor = vec3(2.55, 0.5, 0.0) * lightColor;
			
			lens_strength = 150.0 * lensBrightness;
			lenscolor *= lens_strength;
			
			lensFlare1 = max(pow(max(1.0 - smoothCircleDist(-0.27)/1.0,0.1),5.0)-0.85,0.0);
			lensFlare2 = max(pow(max(1.0 - smoothCircleDist(-0.3)/1.0,0.1),5.0)-0.85,0.0);
			lensFlare3 = max(pow(max(1.0 - smoothCircleDist(-0.33)/1.0,0.1),5.0)-0.85,0.0);
			
			lensFlare = clamp(lensFlare1 * lensFlare2 * lensFlare3, 0.0, 1.0);
			
			color += lensFlare * lenscolor * sunvisibility * (1.0-rainStrength*1.0);
		
			lenscolor = vec3(2.0, 2.0, 0.0) * lightColor;
			
			lens_strength = 150.0 * lensBrightness;
			lenscolor *= lens_strength;
			
			lensFlare1 = max(pow(max(1.0 - smoothCircleDist(-0.82)/1.0,0.1),5.0)-0.85,0.0);
			lensFlare2 = max(pow(max(1.0 - smoothCircleDist(-0.85)/1.0,0.1),5.0)-0.85,0.0);
			lensFlare3 = max(pow(max(1.0 - smoothCircleDist(-0.88)/1.0,0.1),5.0)-0.85,0.0);
			
			lensFlare = clamp(lensFlare1 * lensFlare2 * lensFlare3, 0.0, 1.0);
			
			color += lensFlare * lenscolor * sunvisibility * (1.0-rainStrength*1.0);
		
			lenscolor = vec3(0.0, 1.0, 0.0) * lightColor;
			
			lens_strength = 150.0 * lensBrightness;
			lenscolor *= lens_strength;
			
			lensFlare1 = max(pow(max(1.0 - smoothCircleDist(-1.02)/1.0,0.1),5.0)-0.85,0.0);
			lensFlare2 = max(pow(max(1.0 - smoothCircleDist(-1.05)/1.0,0.1),5.0)-0.85,0.0);
			lensFlare3 = max(pow(max(1.0 - smoothCircleDist(-1.08)/1.0,0.1),5.0)-0.85,0.0);
			
			lensFlare = clamp(lensFlare1 * lensFlare2 * lensFlare3, 0.0, 1.0);
			
			color += lensFlare * lenscolor * sunvisibility * (1.0-rainStrength*1.0);
		
			lenscolor = vec3(0.8, 0.8, 0.0) * length(lightColor);
			
			lens_strength = 0.2 * lensBrightness;
			lenscolor *= lens_strength;
			
			lensFlare1 = max(pow(max(1.0 - cirlceDist(-0.7, 0.5)/1.0,0.1),5.0)-0.1,0.0);
			lensFlare2 = max(pow(max(1.0 - cirlceDist(-0.9, 0.5)/1.0,0.1),5.0)-0.1,0.0);
			
			lensFlare = clamp(lensFlare2 - lensFlare1, 0.0, 1.0);
			color += lensFlare*lensFlare * lenscolor * sunvisibility * (1.0-rainStrength*1.0)*1.3;
		
			lenscolor = vec3(0.0, 0.0, 0.9) * length(lightColor);
			
			lens_strength = 0.2 * lensBrightness;
			lenscolor *= lens_strength;
			
			lensFlare1 = max(pow(max(1.0 - cirlceDist(-0.9, 0.5)/1.0,0.1),5.0)-0.1,0.0);
			lensFlare2 = max(pow(max(1.0 - cirlceDist(-1.07, 0.5)/1.0,0.1),5.0)-0.1,0.0);
			
			lensFlare = clamp(lensFlare2 - lensFlare1, 0.0, 1.0);
			color += lensFlare*lensFlare * lenscolor * sunvisibility * (1.0-rainStrength*1.0)*1.3;
		
			lenscolor = vec3(0.0, 0.9, 0.0) * length(lightColor);
			
			lens_strength = 0.2 * lensBrightness;
			lenscolor *= lens_strength;
			
			lensFlare1 = max(pow(max(1.0 - cirlceDist(-0.8, 0.5)/1.0,0.1),5.0)-0.1,0.0);
			lensFlare2 = max(pow(max(1.0 - cirlceDist(-1.0, 0.5)/1.0,0.1),5.0)-0.1,0.0);
			
			lensFlare = clamp(lensFlare2 - lensFlare1, 0.0, 1.0);
			color += lensFlare*lensFlare * lenscolor * sunvisibility * (1.0-rainStrength*1.0)*1.3;
		
			lenscolor = vec3(0.85, 0.0, 0.0) * length(lightColor);
			
			lens_strength = 0.2 * lensBrightness;
			lenscolor *= lens_strength;
			
			lensFlare1 = max(pow(max(1.0 - cirlceDist(-0.6, 0.5)/1.0,0.1),5.0)-0.1,0.0);
			lensFlare2 = max(pow(max(1.0 - cirlceDist(-0.8, 0.5)/1.0,0.1),5.0)-0.1,0.0);
			
			lensFlare = clamp(lensFlare2 - lensFlare1, 0.0, 1.0);
			color += lensFlare*lensFlare * lenscolor * sunvisibility * (1.0-rainStrength*1.0)*1.3;