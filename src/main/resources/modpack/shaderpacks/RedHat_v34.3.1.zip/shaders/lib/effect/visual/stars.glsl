
vec3 drawStar(vec3 fposition,vec3 color) {
vec3 sVector = normalize(fposition);
float cosT = dot(sVector,upVec);
float McosY = MdotU;
float cosY = SdotU;
//star generation
/*----------*/
vec3 tpos = vec3(gbufferModelViewInverse * vec4(fposition,1.0));
vec3 wvec = normalize(tpos);
vec3 wVector = normalize(tpos);
vec3 intersection = wVector*(17.0/(wVector.y));



//float canHit = length(intersection)-length(tpos);

	vec2 wind = vec2(abs(frameTimeCounter/1000.-0.5),abs(frameTimeCounter/1000.-0.5));


	vec3 wpos = tpos.xyz+cameraPosition;
	intersection.xz = intersection.xz + 5.0*cosT*intersection.xz;		//curve the star pattern, because sky is not 100% plane in reality
	vec2 coord = (intersection.xz+wind*10)/512.0;
	vec2 coord1 = (intersection.xz+wind*10)/128.0;
	float noise = texture2D(noisetex,fract(coord.xy/2.0)).x;

	  float N = 8.0;
vec3 star_color = vec3(RS,GS,BS)*1.0*moonVisibility*(1-rainStrength) + moonlight*48.0*pow(max(McosY,0.0),N)*(N+1)/6.28  * (1-rainStrength)*moonVisibility ;	//coloring stars
/*----------*/

	noise += texture2D(noisetex,fract(coord.xy)).x/2.0;
	noise += texture2D(noisetex,fract(coord1.xy)).x/2.0;

	float cl = max(noise-1.7,0.0);
	float ef = 0.01;

      float star2 = (1.0 - (pow((1-rainStrength*0.9)*ef,cl)))*max(cosT,0.0);


vec3 s = mix(color,star_color,star2);



//s = mix(s,star_color,star);  //mix up sky color and stars



return s;
}