vec2 coord = (wpos.xz/(240*CAUSTIC_SIZE));
float noise = texture2D(noisetex,fract(coord.xy/2.0)- frameTimeCounter/300/CAUSTIC_SPEED).x;
noise += texture2D(noisetex,fract(coord.xy)- frameTimeCounter/200/CAUSTIC_SPEED).x*9.0;