#version 130

// !! DO NOT REMOVE !! !! DO NOT REMOVE !!

// This code is from Chocapic13' shaders
// Read the terms of modification and sharing before changing something below please !

// !! DO NOT REMOVE !! !! DO NOT REMOVE !!

const bool gaux2MipmapEnabled = true;

#define FSH
#include "/program/end/composite2.glsl"
