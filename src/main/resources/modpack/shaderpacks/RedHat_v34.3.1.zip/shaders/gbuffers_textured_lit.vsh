#version 130

/*

// !! DO NOT REMOVE !! !! DO NOT REMOVE !!

// This code is from Chocapic13' shaders
// Read the terms of modification and sharing before changing something below please !

// !! DO NOT REMOVE !! !! DO NOT REMOVE !!

//------------------------------------
//RedHat - Based on Chocapic13' and CYBOX
//
//If you have questions, suggestions or bugs you want to report, please contanct me on curseforge
//
//
//Before editing, please read the LICENSE
//Thanks
//------------------------------------
*/

varying vec4 color;
varying vec4 texcoord;
varying vec4 lmcoord;
varying vec3 normal;

//////////////////////////////VOID MAIN//////////////////////////////
//////////////////////////////VOID MAIN//////////////////////////////
//////////////////////////////VOID MAIN//////////////////////////////
//////////////////////////////VOID MAIN//////////////////////////////
//////////////////////////////VOID MAIN//////////////////////////////

void main() {
	
	gl_Position = ftransform();
	
	color = gl_Color;
	
	texcoord = gl_TextureMatrix[0] * gl_MultiTexCoord0;
	
	lmcoord = gl_TextureMatrix[1] * gl_MultiTexCoord1;
	
	gl_FogFragCoord = gl_Position.z;
	
	normal = normalize(gl_NormalMatrix * gl_Normal);
}