#version 130

#define MAX_COLOR_RANGE 48.0              //[2.0 4.0 6.0 8.0 10.0 12.0 14.0 16.0 18.0 20.0 22.0 24.0 26.0 28.0 30.0 32.0 34.0 36.0 38.0 40.0 42.0 44.0 46.0 48.0 50.0 52.0 54.0 56.0 58.0 60.0 62.0 64.0 66.0 68.0 70.0 72.0 74.0 76.0 78.0 80.0 82.0 84.0 86.0 88.0 90.0 92.0 94.0 96.0 98.0 100.0]
#ifdef SSAO
const float ambientOcclusionLevel = 0.0;
#else
const float ambientOcclusionLevel = 1.0;
#endif

// !! DO NOT REMOVE !! !! DO NOT REMOVE !!

// This code is from Chocapic13' shaders
// Read the terms of modification and sharing before changing something below please !

// !! DO NOT REMOVE !! !! DO NOT REMOVE !!

//------------------------------------
//RedHat - Based on Chocapic13' and CYBOX
//
//If you have questions, suggestions or bugs you want to report, please contact me on Discord
//
//
//Before editing, please read the LICENSE
//Thanks
//------------------------------------

#include "/lib/defines/composite.h"

const float 	wetnessHalflife 		= 70.0f;  //[10.0f 20.0f 30.0f 40.0f 50.0f 60.0f 70.0f 80.0f 90.0f 100.0f]
const float 	drynessHalflife 		= 70.0f;  //[10.0f 20.0f 30.0f 40.0f 50.0f 60.0f 70.0f 80.0f 90.0f 100.0f]

const bool 		shadowHardwareFiltering = true;
const float centerDepthHalflife = 2.3f; //[1.0f 1.1f 1.2f 1.3f 1.4f 1.5f 1.6f 1.7f 1.8f 1.9f 2.0f 2.1f 2.2f 2.3f 2.4f 2.5f 2.6f 2.7f 2.8f 2.9f 3.0f]
const int 		noiseTextureResolution  = 1524;   //[128 256 512 1024 1524 2048 2563 3072 3563 4096 6170 8192 10290 16389]


#define SHADOW_MAP_BIAS 0.85           //[0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define FSH

#include "/program/composite.glsl"


